#include<iostream>
using namespace std;
float PI = 3.142;


class Shape {
protected:
    float width, height, side_R;
public:
    Shape(float w, float h) { //Constructor with height and width parameters
        width = w;
        height = h;
        
    }
    Shape(float s) { side_R = s; } //Second constructor with side / radius parameter 

};

class Rectangle : public Shape {

public:
    Rectangle(float w, float h) : Shape( w , h){} 
    float getArea() { return width * height; }
    
};
class Square : public Shape {

public:
    Square(float s): Shape(s) { }    
    float getArea() { return side_R * side_R; };
};

class Circle : public Shape {

private:   
    float radius;

public:
    Circle(float r): Shape(r){}
    float getArea() { return 4 * PI * side_R; }
};




int main() {
    Rectangle r1(3,146); // Object from Rectangle class
    Square s1(5);        //Object from Square class
    Circle c1(10);       // Object from Circle class
    

    cout << "The area of the rectangle is: " << r1.getArea() << endl;
    cout << "The area of the square is: " << s1.getArea() << endl;
    cout << "The area of the circle is: " << c1.getArea() << endl;
    return 0;

}
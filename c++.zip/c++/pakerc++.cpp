#include<iostream>

using namespace std;

int NUM = 4; // supposed to be dynamic NOT static


void test(bool expected, double actual, char* testName);
void small_felt(double arr[]);
void big_felt(double arr[]);

void main(){

	double arr[] = {745.2, 1023 , 333.5 , 66.6};
	small_felt(arr);
	big_felt(arr);	

	test(true, 66.6, "small value test");
	test(true, 1023, "big value test");
}

void small_felt(double array[]){

	// int num = sizeof(arr)/sizeof(arr[0]);

	double smallest = array[0];

	//for (int i = 0; i < num; i++)
 
   	for (int i = 0; i < num; i++) {
      if (array[i] < smallest) {
         smallest = array[i];
      }
   	}

   cout<<"The smalled Value is \n";
   cout<< smallest;

}

void big_felt(double array[]){

	// int num = sizeof(arr)/sizeof(arr[0]);

	double biggest = array[0];

	//for (int i = 0; i < num; i++)
 
   	for (int i = 0; i < num; i++) {
      if (array[i] > biggest) {
         biggest = array[i];
      }
   	}

   cout<<"The biggest Value is \n";
   cout<< biggest;

}

void test(bool expected, double actual, char* testName){
 	if(expected == actual){

			
	}
 	else{
		
 		 
 		 cout<< testName;
		 cout<<" \n Failed expected: \n";
  		 cout<< expected;
  		 cout << "\n actual\n";
  		 cout<< actual;
 	}
 }
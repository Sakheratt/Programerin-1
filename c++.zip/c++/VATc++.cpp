#include<iostream>
using namespace std;

int sum (int a, int b){

	int c = a + b;

	return c;

}


int main(){

	int x = sum(3, 4);

	cout << x << endl;

	return 0;
}
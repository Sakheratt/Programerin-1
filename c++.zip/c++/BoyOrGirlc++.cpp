#include <iostream>
using namespace std;


void main (){

	bool girl = false;
	int N = 10;

	long personalNumber[N];
	int gender = 0;



do{



	cout << "Are u a girl(1) or boy(0)?"; 
	cin >> gender;

	if (gender == 0){
		cout << "You have entered a man!\n"; 
	
	}

	else if(gender == 1){
		cout << "You have entered a woman!\n"; 
		
	}
	cout << "enter personal Number: "; 
	
	for(int i = 1; i <= N; i++)  
    {  
	    
        cin >> personalNumber[i];
    }


   
   if(personalNumber[N-1] % 2 == 0 && gender == 1){

   		girl = true;
   		cout <<"You are a wonman!\n";
   		cout <<"You are a wonman!\n";
   		cout <<"Have a nice day!\n";
   		
   }

   else if (personalNumber[N-1] % 2 == 1 && gender == 0){
   		girl = true;
   		cout <<"You are a man!\n";
   		cout <<"Have a nice day!\n";
   }

   else{
   	girl = false;

   	cout <<"Start over please!\n";
   }





}while(girl = false);


	
    



}
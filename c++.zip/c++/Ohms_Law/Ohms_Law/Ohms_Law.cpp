#include<iostream> //input output => cout cin
using namespace std;


struct Ohms_Law {
	float u, r, i = 1; //u = volts, r = resistance, i = current

};


int main() {

	Ohms_Law law_1, law_2, law_3;


	char variable;


	do {
	cout << "Which variable do you want to calculate? Current(i) || Resistance(r) || Volts (u) || Quitt (q): ";
	cin >> variable;
	

		if (variable == 'u' || variable == 'U') { //if the user enters Volts

			cout << "\n Please enter the current value: "; cin >> law_1.i;
			cout << "\n Please enter the resistense value: "; cin >> law_1.r;
			law_1.u = law_1.i * law_1.r;	// first law
			cout << "\n The Volts value is: " << law_1.u;
		}

		else if (variable == 'i' || variable == 'I') { //if the user enters Current
			cout << "\n Please enter the Volts value: "; cin >> law_2.u;
			cout << "\n Please enter the resistense value: "; cin >> law_2.r;
			law_2.i = law_2.u / law_2.r;	//second
			cout << "\n The current value is: " << law_2.i;

		}

		else if (variable == 'r' || variable == 'R'){	//if the user enters Resistence
			cout << "\n Please enter the Volts value: "; cin >> law_3.u;
			cout << "\n Please enter the current value: "; cin >> law_3.i;
			law_3.r = law_3.u / law_3.i;	//third
			cout << "\n The Resistence value is: " << law_3.r << endl;

		}
		//I know it is not optimal, but I used it because the quitt functionality did not work :)! waiting for feedback t fix it
		else {
			exit(2);
		}

		

		cout << "\n Good job!" << endl; 
	


	} while (variable == 'q' || 'Q');

	
	

	
	return 0;
}


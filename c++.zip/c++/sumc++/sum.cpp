#include <iostream>
#include "sum.h"
using namespace std;


int main(){

	double arr[] = {1.1 , 5.6 , 7.7};

	double x = sum(arr);
	double y = kvad_sum(arr);
	cout << "Sum of array elements is: "; cout << x;
	cout <<"Sum of the square root of the array elements is: ";cout << y;



	return 0;

}
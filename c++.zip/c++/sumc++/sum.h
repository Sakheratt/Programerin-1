#ifndef HEADER_FILE
#define HEADER_FILE


double S = 0;


double sum(double arr[]){

	
	//int arrayLength =  sizeof arr / sizeof *arr;
	//for(int i = 0; i <= arrayLength; i++)

	for(int i = 0; i <= SIZE; i++)
    {
        s = s + arr[i];
    }


	return s;
}

double kvad_sum(double arr[]){

	//int arrayLength = sizeof arr / sizeof *arr;
	//for(int i = 0; i <= arrayLength; i++)

	
	for(int i = 0; i <= SIZE; i++)
    {
        s = s + (arr[i] * arr[i]);
    }


	return s;
	
}


#endif
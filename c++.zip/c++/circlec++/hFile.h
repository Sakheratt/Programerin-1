#ifndef HEADER_FILE
#define HEADER_FILE



double area(double r){

	return r * r * PI;
}

double omks(double r){

	return 2 * r * PI;
}




#endif
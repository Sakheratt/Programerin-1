#include<iostream>
#include"hFile.h"

using namespace std;

int main(){

	double r = 0;
	
	
	cout << "Enter Radius: ";
	cin >> r;


	
	double ar = area(r); 

	double om = omks(r);

	

	cout << "The area is: ";
	cout << ar;

	cout << "\nThe circumference is: "; cout << om;
	
	return 0;
}
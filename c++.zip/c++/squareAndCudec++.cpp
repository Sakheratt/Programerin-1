#include <iostream>
using namespace std;



	int main(){

	int x = 0;

	

	cout << "Enter a digit! (1-4) \n";
	cin >> x;

	

	switch(x){
		case 1: x = 1; cout << "u entered 1 \n"; break;
		case 2: x = 2; cout << "u entered 2 \n";	break;
		case 3: x = 3;cout << "u entered 3 \n";	break;
		case 4: x = 4; cout << "u entered 4 \n";	break;

		break;
	}


	
	return 0;
}
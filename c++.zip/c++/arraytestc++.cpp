#include <iostream>
using namespace std;

int main(){


	int array [] = {1,2,3};

	cout << array[1] << endl;


	
	return 0;
}
#include<iostream>
using namespace std;


void calc(int max_number){
	int x = 1;
	int y = 0;

	while(x < max_number){
		cout << x << endl;
		x *= 2;
		y++;
	}

	
	
	cout << max_number << endl;
	cout <<"\ncrowns in "; cout << y; cout << days << endl; 

}

void main(){

	int max_number = 0;

	cout << "Please enter the numer needed to be reached: ";
	cin >> max_number;
	calc(max_number);
	
}



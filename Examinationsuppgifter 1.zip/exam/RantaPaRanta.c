#include <stdio.h>
#include <stdbool.h>



void calc(int max_number){
	int x = 1;
	int y = 0;

	while(x < max_number){
		printf("%d\t", x);
		x *= 2;
		y++;
	}

	printf("\nYou will reach %d crowns in %d days\n",max_number, y );
}

void main(){

	int max_number = 0;
	printf("Please enter the numer needed to be reached: " );
	scanf("%d", &max_number); 
	calc(max_number);
	
}



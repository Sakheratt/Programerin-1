#include <stdio.h>
#include <stdbool.h>

float convertTemp(float fah);

void main(){

	char response;


	do{
	float fah = 0.0;
	printf("Please enter temperature in Fahrenheit: ");
	scanf("%f", &fah);
	float cel = convertTemp(fah);
	printf("\nThe temperature in Celsius is: %f ", cel);
	printf("\nDo you want to try another operation? Y(es) or N(o): ");
	response = getchar();
    getchar();
	} while(response == 'Y' || response == 'y');

	
}

float convertTemp(float fah){
	float cel = (fah - 32) * 5 / 9;
	return cel;
}


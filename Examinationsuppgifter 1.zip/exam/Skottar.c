#include <stdio.h>
#include <stdbool.h>

bool leapYear(int year){

	if (year % 400 == 0) {
      return true;
   }
  
   else if (year % 100 == 0) {
      return false;
   }
   
   else if (year % 4 == 0) {
      return true;
   }
  
   else {
     return false;
   }
}




void main(){
	int year = 0;
	printf("Please Enter a year: ");
	scanf("%d", &year);
	bool leap = leapYear(year);

	if(leap){
		printf("The year you have entered is a leap year! \n");
	}
	else{
		printf("The year you have entered is NOT a leap year! \n");
	}


	
}



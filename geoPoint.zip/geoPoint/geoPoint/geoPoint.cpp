#include<iostream>
#include <list>
using namespace std;
float PI = 3.142;


class Shape {
private:
    double width, height, side_R, radius;
public:
    Shape() {  }

    void setSide(float r) { side_R = r; }
    double getSquareArea() { return side_R * 4; }
    void setHight(float h) { height = h; }
    void setWidth(float w) { width = w; }
    double getRectangleArea() { return height * width; }
    void setRadius(float r) { radius = r; }
    double getCircleArea() {  return (PI * radius * radius); }
};


int main() {

    list<Shape*>shapeList;
    Shape* square = new Shape;
    square->setSide(5);
    double s = square->getSquareArea();
    cout << "square area = " << s << endl;

    shapeList.push_back(square);

    Shape* rectangle = new Shape;
    rectangle->setWidth(10);
    rectangle->setHight(15);

    double r = rectangle->getRectangleArea();
    cout << "The rectangle area is: " << r << endl;
    shapeList.push_back(rectangle);

    Shape* circle = new Shape;
    circle->setRadius(2);
    double c = circle->getCircleArea();

    cout << " The circle area is : " << c << endl;

    shapeList.push_back(circle);





    return 0;

}
﻿#include <iostream>
#include"sphere.h"



double PI = 3.142;


    //Sphere()::Sphere{} //empty constructor
    void Sphere:: setRadius(int r)    { radius = r; }    //setter
    double Sphere:: getVolume()       { return ((PI * 4 * radius * radius * radius) / 3);} //return volume as a double
    double Sphere::getArea()         { return (PI * 4 * radius * radius); } // return area as a double




int main()
{
    Sphere newSphere;
    //gives the radius a value.
    newSphere.setRadius(5);
    //variables that retrieve values ​​from the class
    cout << " In case the radius of the sphere: r = 5" << endl;


    double volume = newSphere.getVolume();
    cout << " the Volume of the sphere is: " << volume << endl;

    double area = newSphere.getArea();
    cout << " the Area of the sphere is: " << area << endl;

    /////////////////////////////////////////////////////////////

    Sphere newSphere2;
    //gives the radius a new value.
    newSphere2.setRadius(-3);
    volume = newSphere2.getVolume();
    cout << "\n\n In case the radius of the sphere: r = -3" << endl;


    cout << " the Volume of the sphere is: " << volume << endl;

    area = newSphere.getArea();
    cout << " the Area of the sphere is: " << area << endl;

    return 0;
}
 

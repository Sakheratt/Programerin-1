#ifndef SPHERE_H
#define SPHERE_H
using namespace std;
class Sphere
{

private:
    int radius;

public:
    void setRadius(int r);  //setter
    double getVolume(); //return volume as a double
    double getArea(); // return area as a double

};

#endif